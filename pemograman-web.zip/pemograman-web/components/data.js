export const sekelas = [
  {
    id:'1',
    nama: 'alma',
    telepon:'081212341234',
    image: require('../assets/pulu.jpeg'),
     description: 'alma pacar yugyeom'
  },
  {
    id:'2',
    nama: 'zizi',
    telepon:'089898745632',
    image: require('../assets/monmaap.jpeg'),
     description: 'zizi teman sedari kecil'
  }
];