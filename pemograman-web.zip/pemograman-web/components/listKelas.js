import React from 'react';
import { View, FlatList, StyleSheet } from 'react-native';
import Kontak from '../components/kontak'; // Correct import statement
import { sekelas } from './data';

export default function ListKelas({ navigation }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={sekelas}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Kontak Kontak={item} onPress={() => navigation.navigate('Detail', { Kontak: item })} />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
