import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function detailSekelas({ route }) {
  const { Kontak } = route.params;

  return(
    <View style={styles.container}>
      <Image source={Kontak.image} style={styles.img} />
      <Text style={styles.title}>{Kontak.nama}</Text>
      <Text style={styles.telp}>{Kontak.telepon}</Text>
      <Text style={styles.description}>{Kontak.description}</Text>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
  },
  img: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  telp: {
    fontSize: 18,
    color: '#3498db',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
  },
});