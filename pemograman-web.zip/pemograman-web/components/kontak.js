import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function Kontak({ Kontak, onPress }) {
  return (
    <TouchableOpacity onPress={() => onPress(Kontak)}>
      <View style={styles.container}>
        <Image source={Kontak.image} style={styles.img} />
        <View style={styles.teks}>
          <Text style={styles.title}>{Kontak.nama}</Text>
          
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 80,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: 'blue',
  },
  img: {
    margin: 15,
    width: 50,
    height: 50,
  },
  teks: { flex: 1 },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  telepon: {
    fontSize: 14,
    color: '#3498db',
  },
});
